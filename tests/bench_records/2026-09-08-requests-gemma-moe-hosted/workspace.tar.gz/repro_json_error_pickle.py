import pickle
import requests

try:
    error = requests.exceptions.JSONDecodeError('Extra data', '{}{}', 2)
    pickled_error = pickle.dumps(error)
    unpickled_error = pickle.loads(pickled_error)
    print("Successfully unpickled JSONDecodeError")
except Exception as e:
    print(f"Failed to unpickle JSONDecodeError: {e}")
    import traceback
    traceback.print_exc()
